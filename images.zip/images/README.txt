The images licensed by Pixabay License. They can be accessed using the links below.

Pixabay License
Free for commercial use
No attribution required


https://pixabay.com/illustrations/strawberry-crayons-drawing-1485456/
Image by Kazejin from Pixabay 

https://pixabay.com/vectors/love-heart-disjunct-fruit-cherry-3040894/
Image by Ronny Overhate from Pixabay

https://pixabay.com/vectors/cherry-symbol-color-fruit-isolated-5104143/
Image by DoomSlayer from Pixabay 

https://pixabay.com/vectors/neon-seven-numbers-numerals-sign-145091/
Image by OpenClipart-Vectors from Pixabay 

https://pixabay.com/vectors/lemon-yellow-fruits-citrus-foods-576400/
Image by OpenClipart-Vectors from Pixabay 

https://pixabay.com/vectors/orange-fruit-citrus-healthy-309985/
Image by Clker-Free-Vector-Images from Pixabay 

https://pixabay.com/vectors/heart-love-holiday-valentines-red-26790/
Image by Clker-Free-Vector-Images from Pixabay 

https://pixabay.com/vectors/grapes-fruit-food-wine-plant-vine-34298/
Image by Clker-Free-Vector-Images from Pixabay



